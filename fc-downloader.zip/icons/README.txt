fc-downloader — App Icon assets (Buddy / Wink)

PNG: fc-downloader-16/32/48/64/128/256/512/1024.png
Vector: fc-downloader.svg
Windows: fc-downloader.ico
macOS: fc-downloader.icns  (or rebuild: iconutil -c icns fc-downloader.iconset)

Brand: gradient #5b8cff -> #2f6df0 -> #1c3fb0 / accent #2f6df0 / Apple squircle (superellipse n=4.6)
